package projectJava;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Manager extends JFrame implements ActionListener{
	JLabel fl1,fl2,fl3,ttl1,ttl2;
	JComboBox fj1,fj2,fj3;
	JButton fb1,fb3;
	JPasswordField p1;
	JTextField ft1,t1,t2;
	String[] fpre1={"Report Issue","Food Related","Cleaning Related","Room Maintenence","Others Specify"};
	JTextField wf;
	Manager()
	{
		this.setVisible(true);
		this.setTitle("Manager Portal");
		ttl1=new JLabel("SITARA ",SwingConstants.RIGHT);
		ttl1.setFont(new Font("Serif",Font.ITALIC,25));
		ttl2=new JLabel("EMBASSY",SwingConstants.LEFT);
		ttl2.setFont(new Font("Serif",Font.ITALIC,25));
		fl1=new JLabel("Select The Issue",SwingConstants.CENTER);
		fj1=new JComboBox(fpre1);
		fl2=new JLabel("Enter Id",JLabel.CENTER);
		wf= new JTextField("");
		wf.setText("Sitara_");
		fl3=new JLabel("Enter Password",SwingConstants.CENTER);
		p1=new JPasswordField();
		fb1=new JButton("Submit Report");
		fb3=new JButton("Clear");
		Container con=getContentPane();
		con.setLayout(new GridLayout(5,2));
		con.add(ttl1);
		con.add(ttl2);
		con.add(fl1);
		con.add(fj1);
		con.add(fl2);
		con.add(wf);
		con.add(fl3);
		con.add(p1);
		con.add(fb1);
		con.add(fb3);
		fb1.addActionListener(this);
		fb3.addActionListener(this);
	}
	String[] fpre2={"Role","Food Dept","Cleaning Dept","Room Maintenence Dept","Wi Fi Dept","Parking Dept"};
	Manager(int ig)
	{
		this.setVisible(true);
		this.setTitle("Employee Portal");
		ttl1=new JLabel("SITARA ",SwingConstants.RIGHT);
		ttl1.setFont(new Font("Serif",Font.ITALIC,25));
		ttl2=new JLabel("EMBASSY",SwingConstants.LEFT);
		ttl2.setFont(new Font("Serif",Font.ITALIC,25));
		fl1=new JLabel("Select The Profession",SwingConstants.CENTER);
		fj1=new JComboBox(fpre2);
		fl2=new JLabel("Enter Id",JLabel.CENTER);
		wf= new JTextField("");
		wf.setText("Sitara_");
		fl3=new JLabel("Enter Password",SwingConstants.CENTER);
		p1=new JPasswordField();
		fb1=new JButton("Submit Report");
		fb3=new JButton("Clear");
		Container con=getContentPane();
		con.setLayout(new GridLayout(5,2));
		con.add(ttl1);
		con.add(ttl2);
		con.add(fl1);
		con.add(fj1);
		con.add(fl2);
		con.add(wf);
		con.add(fl3);
		con.add(p1);
		con.add(fb1);
		con.add(fb3);
		fb1.addActionListener(this);
		fb3.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==fb1)
		{
			String pass=new String(p1.getPassword());
			String ui=new String(wf.getText());
			try
			{
				if(ui.equals("Sitara_raja") && pass.equals("raja2003")||ui.equals("Sitara_gowtham") && pass.equals("1234")||ui.equals("Sitara_pavan") && pass.equals("123456")){
				Registration r=new Registration(5.2);
				r.setSize(500,500);
				this.setVisible(false);
				}
				else
				{
					wf.setText("Invalid Login");
					wf.setBackground(getForeground().RED);
					p1.setText("");
					p1.setBackground(getForeground().RED);
				}
				
			}
			catch(NullPointerException ne)
			{
				System.out.println(ne.getMessage());
			}
		}
		else if(ae.getSource()==fb3)
		{
			wf.setText("Sitara_");
			p1.setText(null);
			wf.setBackground(getBackground().brighter());
			p1.setBackground(getBackground().brighter());
		}
	}
}
