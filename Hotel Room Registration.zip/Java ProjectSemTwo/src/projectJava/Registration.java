package projectJava;
import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class Registration  extends JFrame implements ActionListener{
	JLabel ttl1,ttl2,l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;
	JTextField t1,t2,t3,t4,t5,t6,ft1;
	JButton b1,b2;
	String[] gender={"Select","Male","Female","Rather Not To Say"};
	String[] room= {"Select","Single Bed","Double Bed","Deluxe","Business Class"};
	String[] type= {"Select","AC","NON-AC","Non-AC Cooling"};
	String[] food= {"Select","Vegetarian","Non-Vegetarian"};
	String[] week= {"Pick","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
	JComboBox gcb;
	JComboBox rooms;
	JComboBox roomtype;
	JComboBox foodp;
	JComboBox d1,d2;
	Registration()
	{
		//this.setSize(800,1000);
		this.setVisible(true);
		this.setTitle("Hotel Room Registration Form");
		Container con=getContentPane();
		con.setLayout(new GridLayout(14,2));
		ttl1=new JLabel("Hotel ",SwingConstants.RIGHT);
		ttl1.setFont(new Font("Serif",Font.ITALIC,25));
		ttl2=new JLabel("Rooms",SwingConstants.LEFT);
		ttl2.setFont(new Font("Serif",Font.ITALIC,25));
		l1=new JLabel("Enter Name",SwingConstants.CENTER);
		t1=new JTextField();
		l2=new JLabel("ID Provided",JLabel.CENTER);
		t2=new JTextField();
		l5=new JLabel("Gender",JLabel.CENTER);
		l6=new JLabel("RoomType",JLabel.CENTER);
		l7=new JLabel("Conditioning",JLabel.CENTER);
		l8=new JLabel("Food",JLabel.CENTER);
		l9=new JLabel("Pick Visiting Day",JLabel.CENTER);
		l10=new JLabel("Pick Leaving Day",JLabel.CENTER);
		l11=new JLabel("Enter Visiting Date",JLabel.CENTER);
		l12=new JLabel("Enter Leaving Date",JLabel.CENTER);
		 d1=new JComboBox(week);
		 d2=new JComboBox(week);
		 gcb=new JComboBox(gender);
		 rooms=new JComboBox(room);
		 roomtype=new JComboBox(type);
		 foodp=new JComboBox(food);
		t3=new JTextField();
		//t3.setBounds(20,20,40,70);
		t4=new JTextField();
		t5=new JTextField();
		t6=new JTextField();
		l3=new JLabel("Check-in Time",JLabel.CENTER);
		l4=new JLabel("Check-out Time",JLabel.CENTER);
		b1=new JButton("Register");
		b2=new JButton("Reset");
		con.add(ttl1);
		con.add(ttl2);
		con.add(l1);
		con.add(t1);
		con.add(l2);
		con.add(t2);
		con.add(l5);
		con.add(gcb);
		con.add(l6);
		con.add(rooms);
		con.add(l7);
		con.add(roomtype);
		con.add(l8);
		con.add(foodp);
		con.add(l11);
		con.add(t5);
		con.add(l9);
		con.add(d1);
		con.add(l3);
		con.add(t3);
		con.add(l12);
		con.add(t6);
		con.add(l10);
		con.add(d2);
		con.add(l4);
		con.add(t4);
		con.add(b1);
		con.add(b2);
		//con.setBackground(Color.PINK);
		b1.addActionListener(this);
		b2.addActionListener(this);
		}
	JLabel fl1,fl2,fl3,fl4;
	JComboBox fj1,fj2,fj3;
	JButton fb1,fb3;
	String[] fpre1={"Vegetarian Menu","Paneer Biryani","Mushroom Biryani","Full veg Meal","5Star Special","Paneer Tikka","Paneer Butter Masala","Rumali Roti,Butter Naan","Manchuriyan Noodles","Paneer 65","Dal Makhni","Dal Fry","Sambar","Tomato Curry"};
	String[] fpre2={"Non-Vegetarian Menu","Chicken Biryani","Dum Biryani","Full Non-veg Meal","5Star Special","Deep Fried Fish","Mutton Masala","Rumali Roti,Butter Naan","Chicken Manchuriyan Noodles","Chicken 65","Egg Manchuriyan","Parawns","Mutton Biryani","Butter Chicken","Chicken Cutlet","Tandoori Chicken","Chicken Kabab"};
	JTextField wf;
	Registration(int no)
	{
		this.setVisible(true);
		this.setTitle("Room Facilities");
		ttl1=new JLabel("Congratulations ",SwingConstants.RIGHT);
		ttl1.setFont(new Font("Serif",Font.ITALIC,25));
		ttl2=new JLabel("Dear Visitor",SwingConstants.LEFT);
		ttl2.setFont(new Font("Serif",Font.ITALIC,25));
		fl1=new JLabel("Enter Veg-Food Preferences",SwingConstants.CENTER);
			fj1=new JComboBox(fpre1);
			//fj1=new JComboBox(fpre2);
		fl4=new JLabel("Enter Non-Veg Food Preferences",SwingConstants.CENTER);
			fj2=new JComboBox(fpre2);
		fl2=new JLabel("Wi-Fi",JLabel.CENTER);
		t2=new JTextField();
		fl3=new JLabel("Rating",JLabel.CENTER);
		ft1=new JTextField();
		wf= new JTextField("Yes");
		fb1=new JButton("Apply Preferences");
		fb3=new JButton("Contact Services");
		Container con=getContentPane();
		con.setLayout(new GridLayout(6,3));
		con.add(ttl1);
		con.add(ttl2);
		con.add(fl1);
		con.add(fj1);
		con.add(fl4);
		con.add(fj2);
		con.add(fl2);
		con.add(wf);
		con.add(fl3);
		con.add(ft1);
		con.add(fb1);
		con.add(fb3);
		fb1.addActionListener(this);
		fb3.addActionListener(this);
	}
	Registration(double no)
	{
		this.setVisible(true);
		this.setTitle("Room Facilities");
		Container con=getContentPane();
		con.setLayout(new GridLayout(1,2));
		ttl1=new JLabel("THANK ",SwingConstants.RIGHT);
		ttl1.setFont(new Font("Serif",Font.ITALIC,25));
		ttl2=new JLabel("YOU",SwingConstants.LEFT);
		ttl2.setFont(new Font("Serif",Font.ITALIC,25));
		con.add(ttl1);
		con.add(ttl2);
		con.setBackground(Color.pink);
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b1)
		{
			try
			{
				
				String name=t1.getText();
				String id=t2.getText();
				String cin=t3.getText();
				String cout=t4.getText();
				String cind=t5.getText();
				String coutd=t6.getText();
				String o=gcb.getSelectedItem().toString();
				String p=rooms.getSelectedItem().toString();
				String q=roomtype.getSelectedItem().toString();
				String r=foodp.getSelectedItem().toString();
				FileWriter fw=new FileWriter("reg.txt",true);
				System.out.println("Name :"+name+"\tId Provided :"+id+"\tGender :"+o+"\tRoom :"+p+"\tConditioning :"+q+"\tFood Preference :"+r+"\tCheck-In Date"+cind+"\tCheck-In Time :"+cin+"\tCheck-Out Date"+coutd+"\tCheck-Out Time :"+cout+"\n");
				fw.write("Name :"+name+"\tId Provided :"+id+"\tGender :"+o+"\tRoom :"+p+"\tConditioning :"+q+"\nFood Preference :"+r+"\tCheck-In Date"+cind+"\tCheck-In Time :"+cin+"\tCheck-Out Date"+coutd+"\tCheck-Out Time :"+cout+"\n");
				fw.close();
				Registration rf=new Registration(5);
				rf.setSize(500,500);
				
			}
			catch(IOException ie)
			{
				System.out.println(ie.getMessage());
			}
			catch(NullPointerException ne)
			{
				System.out.println(ne.getMessage());
			}
			this.setVisible(false);
		}
		else if(ae.getSource()==b2)
		{
			t1.setText(null);
			t2.setText(null);
			t3.setText(null);
			t4.setText(null);
			t5.setText(null);
			t6.setText(null);
		}
		else if(ae.getSource()==fb1)
		{
			Registration rf=new Registration(5.3);
			rf.setSize(500,500);
			this.setVisible(false);
		}
		else if(ae.getSource()==fb3)
		{
			Support s=new Support();
			s.setSize(400,200);
			this.setVisible(false);
		}
	}
}
