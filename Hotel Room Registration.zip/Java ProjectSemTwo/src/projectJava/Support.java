package projectJava;
import java.awt.*;
import java.net.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
public class Support extends JFrame implements ActionListener{
	JLabel link,l1,mail,m1,ph,p1,a1,ad;
	URL myURL;
	JButton b1;
	Support()
	{
		this.setVisible(true);
		this.setTitle("Support Portal");
		l1=new JLabel("More About Us",JLabel.CENTER);
		link=new JLabel("www.sitara.com",JLabel.CENTER);
		link.setForeground(Color.blue.darker());
		m1=new JLabel("Email Us",JLabel.CENTER);
		mail=new JLabel("sitaraembassy@sitara.com",JLabel.CENTER);
		mail.setForeground(Color.blue.darker());
		ph=new JLabel("Talk To Us",JLabel.CENTER);
		p1=new JLabel("1800-1900-1654",JLabel.CENTER);
		p1.setForeground(Color.blue.darker());
		a1=new JLabel("Reach us",JLabel.CENTER);
		ad=new JLabel("Navi Mumbai-India",JLabel.CENTER);
		ad.setForeground(Color.blue.darker());
		b1=new JButton("HOME");
		Container con=getContentPane();
		con.setLayout(new GridLayout(0,1));
		con.setBackground(getBackground().pink);
		con.add(l1);
		con.add(link);
		con.add(m1);
		con.add(mail);
		con.add(ph);
		con.add(p1);
		con.add(a1);
		con.add(ad);
		con.add(b1);
		b1.addActionListener(this);
		this.pack();
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b1)
		{
			Portal p=new Portal();
			p.setSize(400,200);
			this.setVisible(false);
		}
	}

}
