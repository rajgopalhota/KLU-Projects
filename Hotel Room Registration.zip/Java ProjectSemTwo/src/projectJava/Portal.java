package projectJava;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
public class Portal extends JFrame implements ActionListener{
	JLabel fl1,fl2,fl3,ttl1,ttl2,e1,e2;
	JComboBox fj1,fj2,fj3;
	JButton fb1,fb3;
	JTextField ft1,t1,t2;
	String[] fpre1={"Role","Employee","Manager","Room Booking"};
	JTextField wf;
	Portal()
	{
		this.setVisible(true);
		this.setTitle("Sitara Group Of Hotels");
		e1=new JLabel();
		e2=new JLabel();
		ImageIcon img=new ImageIcon(getClass().getResource("/download.jpg"));
		e2.setIcon(img);
		ttl1=new JLabel("SITARA ",SwingConstants.RIGHT);
		ttl1.setFont(new Font("Serif",Font.ITALIC,30));
		ttl2=new JLabel("EMBASSY",SwingConstants.LEFT);
		ttl2.setFont(new Font("Serif",Font.ITALIC,30));
		fl1=new JLabel("Select Your Role",SwingConstants.CENTER);
		fj1=new JComboBox(fpre1);
		fl2=new JLabel("Enter Your Mobile Number",JLabel.CENTER);
		wf= new JTextField("+91 ");
		fb1=new JButton("Apply Preferences");
		fb3=new JButton("Contact Services");
		Container con=getContentPane();
		Container con1=getContentPane();
		con1.setSize(10, 20);
		con.setLayout(new GridLayout(4,2));
		con.add(ttl1);
		con.add(ttl2);
		con.add(fl1);
		con.add(fj1);
		con.add(fl2);
		con.add(wf);
		con1.add(fb1);
		con1.add(fb3);
		fb1.setBackground(getForeground().orange);
		fb3.setBackground(getForeground().orange);
		fj1.setBackground(getForeground().orange);
		wf.setBackground(getForeground().orange);
		fb1.addActionListener(this);
		fb3.addActionListener(this);
		con.setBackground(getBackground().orange);
		this.pack();
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==fb1)
		{
			if(wf.getText().length()!=14) {
				wf.setText("Enter A Correct Number");
				wf.setBackground(getForeground().red);}
			else {
			try
			{
				String o=fj1.getSelectedItem().toString();
				if(o.equalsIgnoreCase("Room Booking"))
				{
					Registration rf=new Registration();
					rf.setSize(500,500);
					this.setVisible(false);
				}
				else if(o.equalsIgnoreCase("Manager"))
				{
					Manager m=new Manager();
					m.setSize(400,250);
					this.setVisible(false);
				}
				else if(o.equals("Employee"))
				{
					Manager m=new Manager(2);
					m.setSize(400,250);
					this.setVisible(false);
				}
				else if(o.equals("Role"))
				{
					fj1.setBackground(getForeground().red);
				}
				
			}
			catch(NullPointerException ne)
			{
				System.out.println(ne.getMessage());
			}
			}
		}
		else if(ae.getSource()==fb3)
		{
			Support s=new Support();
			s.setSize(400,200);
			this.setVisible(false);
		}
	}
	public static void main(String[] args) {
		Portal p=new Portal();
		p.setSize(400,200);

	}

}
