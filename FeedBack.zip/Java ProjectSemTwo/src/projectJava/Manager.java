package projectJava;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
public class Manager extends JFrame implements ActionListener{
	JLabel fl1,ttl1;
	JComboBox fj1;
	JButton fb1;
	String[] fpre1={"Select Report","SEC-A","SEC-B","SEC-C","SEC-D"};
	Manager()
	{
		this.setVisible(true);
		this.setTitle("Manager Portal");
		ttl1=new JLabel("Delhi Public School",SwingConstants.CENTER);
		ttl1.setFont(new Font("Serif",Font.ITALIC,25));
		fl1=new JLabel("Select The Section",SwingConstants.CENTER);
		fj1=new JComboBox(fpre1);
		fb1=new JButton("Get Report");
		Container con=getContentPane();
		con.setLayout(new GridLayout(0,1));
		con.add(ttl1);
		con.add(fl1);
		con.add(fj1);
		con.add(fb1);
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==fb1)
		{
			String section=new String(fj1.getSelectedItem().toString());
			try
			{
				
			}
			catch(NullPointerException ne)
			{
				System.out.println(ne.getMessage());
			}
		}
	}
}
