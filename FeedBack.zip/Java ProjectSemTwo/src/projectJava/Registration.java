package projectJava;
import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class Registration  extends JFrame implements ActionListener{
	JLabel ttl1,ttl2,l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;
	JTextField t1,t2,t3,t4,t5,t6,ft1;
	JButton b1,b2;
	String[] section= {"Select","SEC-A","SEC-B","SEC-C","SEC-D"};
	String[] subs= {"Select","Mathematics","Chemistry","Physics","English"};
	JComboBox sec,sub;
	ButtonGroup bg;
	JRadioButton r1,r2,r3,r4;
	Registration()
	{
		this.setVisible(true);
		this.setTitle("Student Feedback");
		Container con=getContentPane();
		con.setLayout(new GridLayout(7,2));
		ttl1=new JLabel("Delhi Pub",SwingConstants.RIGHT);
		ttl1.setFont(new Font("Serif",Font.ITALIC,25));
		ttl2=new JLabel("lic School",SwingConstants.LEFT);
		ttl2.setFont(new Font("Serif",Font.ITALIC,25));
		l1=new JLabel("Enter Name",SwingConstants.CENTER);
		t1=new JTextField();
		l2=new JLabel("ID Number",JLabel.CENTER);
		t2=new JTextField();
		l3=new JLabel("Section",JLabel.CENTER);
		sec=new JComboBox(section);
		l4=new JLabel("Subject",JLabel.CENTER);
		sub=new JComboBox(subs);
		b1=new JButton("Submit");
		b2=new JButton("Next");
		l5=new JLabel("Rating",JLabel.CENTER);
		r1=new JRadioButton("Very good");
		r2=new JRadioButton("Average");
		r3=new JRadioButton("Bad");
		bg=new ButtonGroup();
		Box b11=Box.createHorizontalBox();
		bg.add(r1);
		bg.add(r2);
		bg.add(r3);
		b11.add(r1);
		b11.add(r2);
		b11.add(r3);
		con.add(ttl1);
		con.add(ttl2);
		con.add(l1);
		con.add(t1);
		con.add(l2);
		con.add(t2);
		con.add(l3);
		con.add(sec);
		con.add(l4);
		con.add(sub);
		con.add(l5);
		con.add(b11);
		con.add(b1);
		con.add(b2);
		b1.addActionListener(this);
		b2.addActionListener(this);
		}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b1)
		{
			try
			{
				String name=t1.getText();
				String id=t2.getText();
				String rting;
				if(r1.isSelected())
					rting=r1.getText();
				else if(r2.isSelected())
					rting=r2.getText();
				else
					rting=r3.getText();
				String o=sec.getSelectedItem().toString();
				String p=sub.getSelectedItem().toString();
				if(o.equalsIgnoreCase("SEC-A"))
				{
				FileWriter fw=new FileWriter("Section A.txt",true);
				System.out.println("Name :"+name+"\tId Number :"+id+"\tSubject :"+p+"\tRating :"+rting);
				fw.write("Name :"+name+"\tId Number :"+id+"\tSubject :"+p+"\tRating :"+rting);
				fw.close();
				}
				else if(o.equalsIgnoreCase("SEC-B"))
				{
				FileWriter fw=new FileWriter("Section B.txt",true);
				System.out.println("Name :"+name+"\tId Number :"+id+"\tSubject :"+p+"\tRating :"+rting);
				fw.write("Name :"+name+"\tId Number :"+id+"\tSubject :"+p+"\tRating :"+rting);
				fw.close();
				}
				else if(o.equalsIgnoreCase("SEC-C"))
				{
				FileWriter fw=new FileWriter("Section C.txt",true);
				System.out.println("Name :"+name+"\tId Number :"+id+"\tSubject :"+p+"\tRating :"+rting);
				fw.write("Name :"+name+"\tId Number :"+id+"\tSubject :"+p+"\tRating :"+rting);
				fw.close();
				}
				else if(o.equalsIgnoreCase("SEC-D"))
				{
				FileWriter fw=new FileWriter("Section D.txt",true);
				System.out.println("Name :"+name+"\tId Number :"+id+"\tSubject :"+p+"\tRating :"+rting);
				fw.write("Name :"+name+"\tId Number :"+id+"\tSubject :"+p+"\tRating :"+rting);
				fw.close();
				}
			}
			catch(IOException ie)
			{
				System.out.println(ie.getMessage());
			}
			catch(NullPointerException ne)
			{
				System.out.println(ne.getMessage());
			}
		}
		else if(ae.getSource()==b2)
		{
			Registration r=new Registration();
			r.setSize(500,500);
			this.setVisible(false);
		}
	}



}
