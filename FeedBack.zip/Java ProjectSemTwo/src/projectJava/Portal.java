package projectJava;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;
public class Portal extends JFrame implements ActionListener{
	JLabel fl1,fl2,fl3,ttl1,ttl2,e1,e2;
	JComboBox fj1,fj2,fj3;
	JButton fb1,fb3;
	JPasswordField p1;
	JTextField ft1,t1,t2;
	String[] fpre1={"Select","Student","Admin"};
	JTextField wf;
	Portal()
	{
		this.setVisible(true);
		this.setTitle("Feedback Form");
		e1=new JLabel();
		e2=new JLabel();
		ttl1=new JLabel("Delhi Pub",SwingConstants.RIGHT);
		ttl1.setFont(new Font("Serif",Font.ITALIC,30));
		ttl2=new JLabel("lic School",SwingConstants.LEFT);
		ttl2.setFont(new Font("Serif",Font.ITALIC,30));
		fl1=new JLabel("Select Your Role",SwingConstants.CENTER);
		fj1=new JComboBox(fpre1);
		fl2=new JLabel("Enter Your Username",JLabel.CENTER);
		wf= new JTextField("dps_");
		fl3=new JLabel("Password",SwingConstants.CENTER);
		p1=new JPasswordField("");
		fb1=new JButton("Login");
		fb3=new JButton("Reset");
		Container con=getContentPane();
		Container con1=getContentPane();
		con1.setSize(10, 20);
		con.setLayout(new GridLayout(5,2));
		//con.add(e1);
		//con.add(e2);
		con.add(ttl1);
		con.add(ttl2);
		con.add(fl1);
		con.add(fj1);
		con.add(fl2);
		con.add(wf);
		con.add(fl3);
		con.add(p1);
		con1.add(fb1);
		con1.add(fb3);
		fb1.setBackground(getForeground().cyan);
		fb3.setBackground(getForeground().cyan);
		fj1.setBackground(getForeground().pink);
		wf.setBackground(getForeground().pink);
		p1.setBackground(getForeground().pink);
		fb1.addActionListener(this);
		fb3.addActionListener(this);
		con.setBackground(getBackground().pink);
		this.pack();
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==fb1)
		{
			try
			{
				String user=wf.getText().toString();
				String rit=new String(p1.getPassword());
				String o=fj1.getSelectedItem().toString();
				if(o.equalsIgnoreCase("Student"))
				{
					if(user.length()==14){
					Registration rf=new Registration();
					rf.setSize(500,500);
					}
					else
					{
						wf.setText("Invalid User ID");
						p1.setText("");
						wf.setBackground(Color.red);
						p1.setBackground(Color.red);
					}
				}
				else if(o.equalsIgnoreCase("Admin"))
				{
					if(user.equals("dps_admrithvik") && rit.equals("2100032341")){
					Manager m=new Manager();
					m.setSize(400,250);
					}
					else
					{
						wf.setText("Invalid User ID");
						p1.setText("");
						wf.setBackground(Color.red);
						p1.setBackground(Color.red);
					}
				}
				else if(o.equals("Select"))
				{
					fj1.setBackground(getForeground().orange);
				}
				
			}
			catch(NullPointerException ne)
			{
				System.out.println(ne.getMessage());
			}
		}
		else if(ae.getSource()==fb3)
		{
			wf.setText("dps_");
			p1.setText("");
			wf.setBackground(getForeground().pink);
			p1.setBackground(getForeground().pink);
		}
	}
	public static void main(String[] args) {
		Portal p=new Portal();
		p.setSize(400,250);

	}

}
